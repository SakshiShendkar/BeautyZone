package com.SakshiBeautyZone.BeautyZone.Controller;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.SakshiBeautyZone.BeautyZone.Model.contact;

@Controller
public class LoginController {
	@Autowired
	SessionFactory sf;

@RequestMapping("indexpage")
public String indexpage() {
	return"index";
}
@RequestMapping("aboutpage")
public String aboutpage() {
	return"about";
}

@RequestMapping("contactpage")
public String contactpage() {
	return"contact";
}

@RequestMapping("contact")
public String contactpage( contact c) {
	Session s = sf.openSession();
	Transaction t = s.beginTransaction();
	s.save(c);
	t.commit();
    return "contact";
}

@RequestMapping("gallarypage")
public String logoutpage() {
	return"gallary";
}
@RequestMapping("servicepage")
public String page() {
	return"service";
}
@RequestMapping("shoppage")
public String shoppage() {
	return"shop";
}

}



